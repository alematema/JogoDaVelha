package br.edu.undra.jogodavelha.runners;

import java.util.Scanner;

import br.edu.undra.jogodavelha.inteligencia.Analisador;
import br.edu.undra.jogodavelha.model.Jogador;
import br.edu.undra.jogodavelha.model.JogadorComecaOJogo;
import br.edu.undra.jogodavelha.model.JogoDaVelha;
import br.edu.undra.jogodavelha.model.Tabuleiro;

public class JogoDaVelhaVersaoHumanoVersusMaquina {
	
	private static int MAX_JOGOS = 10;
	private JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());
	private Jogador jogador1;
	private Jogador jogador2;
	private Analisador analisador;
	
	public JogoDaVelhaVersaoHumanoVersusMaquina() {
		System.err.println("Criando banco de jogos ...");
		analisador = new Analisador();
		analisador.verboseOff();
		jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM, analisador);
		jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO, analisador);
		jogador1.setOponente(jogador2);
		jogador2.setOponente(jogador1);
		jogador1.setVezDeJogar(Boolean.TRUE);
		jogador2.setVezDeJogar(Boolean.FALSE);
		jogador1.verboseOff();
		jogador2.verboseOff();
	}
	
	public void joga(){
		 	
			
			Scanner s = new Scanner(System.in);
			int posicao;
			
			int jogos=0;
			while(jogos<MAX_JOGOS){

				jogos++;
				jogoDaVelha = new JogoDaVelha(new Tabuleiro());
				jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM, analisador);
				jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO, analisador);
				jogador1.setOponente(jogador2);
				jogador2.setOponente(jogador1);
				analisador.clean();
				analisador.verboseOff();
				jogador1.setVezDeJogar(Boolean.TRUE);
				jogador2.setVezDeJogar(Boolean.FALSE);
				
				jogador1.verboseOn();
				jogador2.verboseOn();
				
				System.out.println("\nJOGANDO JOGO " + jogos);
				
				while(!jogoDaVelha.terminou()){
					
					jogador1.joga();
					
					if(jogoDaVelha.terminou()){
						try {
							Thread.sleep(900);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
					}
					System.out.println("\nSUA VEZ DE JOGAR... digite a posicao (1...9) onde deseja jogar : ");
					try {
						posicao = s.nextInt();
						if(posicao==10){
							jogos=MAX_JOGOS+1;
							break;
						}
					} catch (Exception e) {
						s = new Scanner(System.in);
						posicao=-1;
					}
					
					
					while(!jogador2.jogaNaPosicao(posicao-1)){
						
						System.err.println("\n" + posicao + " É POSIÇÃO INVÁLIDA! VÁLIDAS SÃO ENTRE 1 e 9 E DESOCUPADAS...");
						System.out.println("\nSUA VEZ DE JOGAR... digite a posicao (1...9) onde deseja jogar : ");
						
						try {
							posicao = s.nextInt();
							if(posicao==10){
								jogos=MAX_JOGOS+1;
								break;
							}
						} catch (Exception e) {
							posicao=-1;
							s = new Scanner(System.in);
						}
					}
                                        jogador2.getJogoDaVelha().getTabuleiro().comMascara().descreve();
					if(jogos==MAX_JOGOS+1)break;
					System.err.println("\nCOMPUTADOR PENSANDO...\n");
					
				}//JOGO TERMINOU 
				if(jogos!=MAX_JOGOS+1){
					if(jogoDaVelha.getTabuleiro().primeiroJogadorFezAlgumaTrinca())System.out.println("\n\n\nVOCÊ PERDEU ("+jogoDaVelha.getOndeHouveTrinca() + ") !!! FIM DO JOGO " + jogos);
					else if(jogoDaVelha.getTabuleiro().segundoJogadorFezAlgumaTrinca())System.out.println("\n\n\nVOCÊ GANHOU ("+jogoDaVelha.getOndeHouveTrinca() + ")!!!FIM DO JOGO " + jogos);
					else System.out.println("\n\n\nEMPATE E FIM DO JOGO " + jogos +" <<<<<<-------------------------\n");
					
				}else{
					System.err.println("\n<<<<<<------- bye bye ------>>>>>>>\n");
				}				
				
			}
			
			
	}

}
