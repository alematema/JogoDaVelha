package br.edu.undra.jogodavelha.runners;

public class JogoDaVelhaVersaoHumanoVersusMaquinaRunner {
	
	public static void main(String[] args) {
		JogoDaVelhaVersaoHumanoVersusMaquina vhvm = new JogoDaVelhaVersaoHumanoVersusMaquina();
		vhvm.joga();
	}

}
