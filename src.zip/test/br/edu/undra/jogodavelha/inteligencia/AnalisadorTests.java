package br.edu.undra.jogodavelha.inteligencia;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import br.edu.undra.jogodavelha.model.Jogador;
import br.edu.undra.jogodavelha.model.JogadorComecaOJogo;
import br.edu.undra.jogodavelha.model.JogoDaVelha;
import br.edu.undra.jogodavelha.model.Tabuleiro;

public class AnalisadorTests {

	
	private static Analisador analisador;
	
	@BeforeClass
	public static void setUpClass(){
		System.err.println("Criando banco de Jogos ... ");
		analisador = new Analisador();
	}
	
	@Test public void getPosicoesOndePerderiaDaquiADuasJogadas(){
	
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		jogador1.setOponente(jogador2);
		jogador2.setOponente(jogador1);
		
		jogador1.jogaNaPosicao(Tabuleiro.ZERO);
		jogador2.jogaNaPosicao(Tabuleiro.SEIS);
		
		
		System.out.println("-----------------------------------"+analisador.paraJogador(jogador1).getPosicoesOndePerderiaDaquiADuasJogadas());
		
		jogador1.jogaNaPosicao(Tabuleiro.OITO);
//		jogador2.jogaNaPosicao(Tabuleiro.SEIS);
		
		
		System.out.println("-----------------------------------"+analisador.paraJogador(jogador2).getPosicoesOndePerderiaDaquiADuasJogadas());
		jogador1.getJogoDaVelha().getTabuleiro().semMascara().descreve();
		jogador2.jogaNaPosicao(Tabuleiro.QUATRO);
		
		System.out.println("-----------------------------------"+analisador.paraJogador(jogador1).getPosicoesOndePerderiaDaquiADuasJogadas());
		jogador1.getJogoDaVelha().getTabuleiro().semMascara().descreve();
		jogador1.jogaNaPosicao(Tabuleiro.DOIS);
		System.out.println("-----------------------------------"+analisador.paraJogador(jogador2).getPosicoesOndePerderiaDaquiADuasJogadas());
		jogador1.getJogoDaVelha().getTabuleiro().semMascara().descreve();
	}
	
	@Test public void getPosicoesOndePerderia(){
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		jogador1.setOponente(jogador2);
		jogador2.setOponente(jogador1);
		
		assertTrue(analisador.paraJogador(jogador1).getPosicoesOndePerderia().size()==0);
		
		jogador1.jogaNaPosicao(0);
		jogador2.jogaNaPosicao(6);
		
		
		assertTrue(analisador.paraJogador(jogador1).getPosicoesOndePerderia().size()==0);
		
		jogador1.jogaNaPosicao(4);
		
		
		assertTrue(analisador.paraJogador(jogador2).getPosicoesOndePerderia().size()==5);
		
		
		
	}
	
	@Test public void getPosicoesOndeNaoPerderia(){
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());
	
		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		jogador1.setOponente(jogador2);
		jogador2.setOponente(jogador1);
		
		int posicao = 1;
		
		assertTrue(analisador.paraJogador(jogador1).getPosicoesOndeNaoPerderia().size()==9);
		
		jogador1.jogaNaPosicao(0);
		jogador2.jogaNaPosicao(6);
		
		assertTrue(analisador.paraJogador(jogador1).getPosicoesOndeNaoPerderia().size()==7);
		
		jogador1.jogaNaPosicao(4);
		
		assertTrue(analisador.paraJogador(jogador2).getPosicoesOndeNaoPerderia().size()==1);
		
	}
	
	@Test public void getSubEspaco_EspacoTotalDeJogosJogandoVAlorValidoEmUmaPosicaoValida_UmaRestricaoDoEspacoNoQualSeFezAJogada(){
	
		List<JogoDaVelha> espacoTotal = analisador.getEspacoTotal();
		
		int posicao = 0;
		int valor = 1;
		
		for(posicao=0;posicao<9;posicao++){
			
			for(valor=1;valor<10;valor++){
				
				List<JogoDaVelha> restricao = analisador.noEspaco(espacoTotal).getSubEspaco(posicao,valor);
					
					boolean hasNoOne = true;
					
					for(JogoDaVelha jogo : restricao){
						
						if(jogo.getBaseCorrente().get(posicao)!=valor){
							
							hasNoOne=Boolean.FALSE;
							break;
							
						}
						
					}
					
					assertTrue(hasNoOne);
			}
			
		}
		
	}
	
	@Test public void getSubEspaco_RestricaoAposRestricaoMantemRestricaoOriginal(){
		
		List<JogoDaVelha> espacoTotal = analisador.getEspacoTotal();
		
		int posicao1 = 0;
		int valor1 = 1;
		
		//restricao a todos jogos que  tem valor=valor1 em posicao=posicao1
		List<JogoDaVelha> restricao = analisador.noEspaco(espacoTotal).getSubEspaco(posicao1,valor1);
		
		int posicao2 = 6;
		int valor2 = 2;
		
		//restricao a todos jogos que tem valor = valor1 na posicao=posicao1 AND valor=valor2 na posicao2
		restricao = analisador.noEspaco(restricao).getSubEspaco(posicao2,valor2);
		
		boolean hasNoOneWrongGame = true;
		
		for(JogoDaVelha jogo : restricao){
			
			if(jogo.getBaseCorrente().get(posicao1)!=valor1){//isso jah havia sido testado
				
				hasNoOneWrongGame=Boolean.FALSE;
				break;
				
			}
			
			if(jogo.getBaseCorrente().get(posicao2)!=valor2){
				
				hasNoOneWrongGame=Boolean.FALSE;
				break;
				
			}
			
		}
		
		assertTrue(hasNoOneWrongGame);
		
	}
	
	@Test public void getSubEspaco__PerdeJogoNaRestricaoDoEspacoNoQualSeFezAJogada(){
		
		List<JogoDaVelha> espacoTotal = analisador.getEspacoTotal();
		
		List<Integer> posicoes = new ArrayList<>(Arrays.asList(0,1,2,3,4,5,6,7,8));
		
		int posicao = posicoes.get(0);
		int valor = 1;
		
//		for(posicao=0;posicao<9;posicao++){
//			
//			for(valor=1;valor<10;valor++){
				
				List<JogoDaVelha> restricao = analisador.noEspaco(espacoTotal).getSubEspaco(posicao,valor);
					
					boolean hasNoOne = true;
					
					for(JogoDaVelha jogo : restricao){
						
						if(jogo.getBaseCorrente().get(posicao)!=valor){
							
							hasNoOne=Boolean.FALSE;
							break;
							
						}
					}
					
					assertTrue(hasNoOne);
					
//					posicoes.remove(posicoes.indexOf(0));
					
					posicao = posicoes.get(2);
					valor=2;
					restricao = analisador.noEspaco(restricao).getSubEspaco(posicao,valor);
					
//					posicoes.remove(posicoes.indexOf(2));
//					posicao = posicoes.get(posicoes.indexOf(7));
					
					valor=3;posicao=0;
					while(posicao<posicoes.size()){
						
						List<JogoDaVelha> espaco = analisador.noEspaco(restricao).getSubEspaco(posicoes.get(posicao),valor);
						
						boolean perde = false;
						
						for(JogoDaVelha jogo : espaco){
							
							if(jogo.getTabuleiro().segundoJogadorFezAlgumaTrinca()){
								perde=true;
								System.out.println("\tjogando na posicao "+ posicoes.get(posicao) + " valor="+ valor + " perde " + jogo.getOndeHouveTrinca()+  " " + jogo.getId());
								jogo.getTabuleiro().semMascara().descreve();
								break;
								
							}else// if(jogo.getTabuleiro().primeiroJogadorFezAlgumaTrinca()){
								{System.out.println("jogando na posicao "+ posicoes.get(posicao) + " valor="+ valor +" ganha " + jogo.getOndeHouveTrinca()+" " + jogo.getId());
								jogo.getTabuleiro().semMascara().descreve();
							}
						}
						
						
						posicao++;
					}
					
					
//			}
//		}
	}
	
	

}
