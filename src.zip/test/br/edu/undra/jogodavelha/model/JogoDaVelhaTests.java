package br.edu.undra.jogodavelha.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class JogoDaVelhaTests {

	@Test
	public void getTabuleiro_NovoJogo_TodasPosicoesZero() {

		Tabuleiro tabuleiro = new Tabuleiro();

		JogoDaVelha jogoDaVelha = new JogoDaVelha(tabuleiro);

		for (int i = 0; i < 9; i++) {
			assertEquals(0, jogoDaVelha.getTabuleiro().get(i));
		}

	}

	@Test
	public void jogar_NumTabuleiroNovoSetarValorEntre1e9numaPosicaoEntre0e8_valorJogadoNaquelaPosicao() {

		Tabuleiro tabuleiro = new Tabuleiro();// tabuleiro novo

		JogoDaVelha jogoDaVelha = new JogoDaVelha(tabuleiro);

		jogoDaVelha.naPosicao(1).setValor(1).jogar();
		assertEquals(1, jogoDaVelha.getTabuleiro().get(1));
		// jogoDaVelha.getTabuleiro().descreve();

	}

	@Test
	public void desfazerJogada_NumTabuleiroNovoSetarValorEntre1e9numaPosicaoEntre0e8EUndo_ValorNaquelaPosicaoAntesDosSetting() {

		Tabuleiro tabuleiro = new Tabuleiro();// tabuleiro novo
		tabuleiro.descreve();

		JogoDaVelha jogoDaVelha = new JogoDaVelha(tabuleiro);

		int valorAntesDeJogar = jogoDaVelha.getTabuleiro().get(1);

		jogoDaVelha.naPosicao(1).setValor(1).jogar();
		jogoDaVelha.getTabuleiro().descreve();

		jogoDaVelha.desfazerJogada();

		assertEquals(valorAntesDeJogar, jogoDaVelha.getTabuleiro().get(1));

		jogoDaVelha.getTabuleiro().descreve();
		
		valorAntesDeJogar = jogoDaVelha.getTabuleiro().get(3);

		jogoDaVelha.naPosicao(3).setValor(5).jogar();

		jogoDaVelha.naPosicao(3).setValor(7).jogar();

		jogoDaVelha.desfazerJogada();

		assertEquals(valorAntesDeJogar, jogoDaVelha.getTabuleiro().get(3));

	}

	@Test
	public void oPrimeiroAJogarGanhou_UmJogoEmQueUmaTrincaEhFeitaPorQuemIniciouJogo_Verdadeiro() {

		Tabuleiro tabuleiro = new Tabuleiro();// tabuleiro novo
		tabuleiro.descreve();

		JogoDaVelha jogoDaVelha = new JogoDaVelha(tabuleiro);

		jogoDaVelha.naPosicao(0).setValor(1).jogar();// joga 1 vez

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(3).setValor(2).jogar();

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(1).setValor(3).jogar(); // joga 2 vezes

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(6).setValor(4).jogar();

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(2).setValor(5).jogar();// joga 3 vezes ... faz
														// trinca em 012

		jogoDaVelha.descreve();

		assertTrue(jogoDaVelha.alguemVenceu());

		// 012
		// 345
		// 678

		tabuleiro = new Tabuleiro();// tabuleiro novo
		tabuleiro.descreve();

		jogoDaVelha = new JogoDaVelha(tabuleiro);

		jogoDaVelha.naPosicao(0).setValor(1).jogar();// joga 1 vez

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(3).setValor(2).jogar();

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(4).setValor(3).jogar(); // joga 2 vezes

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(6).setValor(4).jogar();

		assertFalse(jogoDaVelha.alguemVenceu());

		jogoDaVelha.naPosicao(8).setValor(5).jogar();// joga 3 vezes ... faz
														// trinca em 048

		jogoDaVelha.desfazerJogada();
		jogoDaVelha.descreve();

		assertFalse(jogoDaVelha.alguemVenceu());
		
		jogoDaVelha.naPosicao(8).setValor(5).jogar();// joga 3 vezes ... faz
		// trinca em 048
		
		jogoDaVelha.descreve();

		assertTrue(jogoDaVelha.alguemVenceu());
	}

}
