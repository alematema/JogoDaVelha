package br.edu.undra.jogodavelha.model;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import br.edu.undra.jogodavelha.inteligencia.Analisador;

public class JogadorTests {

	private static Analisador analisador;


	@BeforeClass
	public static void setUpClass(){
		System.err.println("Criando banco de jogos ...");
		analisador = new Analisador();
	}
	
	@Test public void jogaNaPosicao_DoisJogadoresNovosUmDelesComecaOJogo_posicaoCorretaEValorCorreto(){
	
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);

		assertEquals(1, jogador1.getProximoValorASerJogado());
		
		jogador1.jogaNaPosicao(Tabuleiro.ZERO);
		
		assertEquals(1, jogador1.getAnteriorValorJogado());
		assertEquals(3, jogador1.getProximoValorASerJogado());
		assertEquals(1, jogador1.getAnteriorValorJogado());
		
		assertEquals(2, jogador2.getProximoValorASerJogado());
		jogador2.jogaNaPosicao(Tabuleiro.QUATRO);
		
		assertEquals(4, jogador2.getProximoValorASerJogado());
		assertEquals(2, jogador2.getAnteriorValorJogado());
		
	}
	
	@Test public void jogaNaPosicao_DoisJogadoresNovosUmDelesComecaOJogoOOutroTentaJogarNaPosicaoQueOprimeiroJogou_JogadaRecusada(){
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);

		
		jogador1.jogaNaPosicao(Tabuleiro.ZERO);
		
		assertFalse(jogoDaVelha.isPosicaoLivre(Tabuleiro.ZERO));	
		
		assertFalse(jogador2.jogaNaPosicao(Tabuleiro.ZERO));
		
		assertEquals(2, jogador2.getProximoValorASerJogado());
		
	}
	
	@Test public void jogaNaPosicao_OMesmoJogadorTentandoJogarDuasOuMaisVezesSeguindamente_EhBarrado(){
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		assertFalse(jogador2.isJogandoCerto());// o segundo nao consegue iniciar jogo
		assertTrue(jogador1.jogaNaPosicao(Tabuleiro.CINCO));// o primeiro comeca o jogo...
		//jogador segundo joga e tenta jogar Mais outra vez sem esperar o primeiro
		assertTrue(jogador2.jogaNaPosicao(Tabuleiro.UM));
		assertFalse(jogador2.jogaNaPosicao(Tabuleiro.OITO));// EH BARRADO
		
		
	}
	
	@Test public void isJogandoCerto(){
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		//garante ser sempre o jogador que comeca o jogo que PODE fazer settings
		assertFalse(jogador2.isJogandoCerto());
		assertTrue(jogador1.isJogandoCerto());
		
		assertTrue(jogador1.jogaNaPosicao(Tabuleiro.CINCO));
		assertTrue(jogador2.isJogandoCerto());
		
	}
	
	@Test
	public void desfazerJogada(){
		
		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);

		
		jogador1.jogaNaPosicao(Tabuleiro.ZERO);
		
		assertFalse(jogoDaVelha.isPosicaoLivre(Tabuleiro.ZERO));
		assertEquals(1, jogador1.getAnteriorValorJogado());
		
		assertTrue(jogador1.desfazerJogada());
		
		assertTrue(jogoDaVelha.isPosicaoLivre(Tabuleiro.ZERO));
		assertEquals(1, jogador1.getProximoValorASerJogado());
		
		jogador1.jogaNaPosicao(Tabuleiro.DOIS);//tem que haver ao menos uma jogada do primeiro jogador!!!
		
		jogador2.jogaNaPosicao(Tabuleiro.CINCO);
		assertFalse(jogoDaVelha.isPosicaoLivre(Tabuleiro.CINCO));
		assertEquals(2, jogador2.getAnteriorValorJogado());
		assertEquals(4, jogador2.getProximoValorASerJogado());
		
		assertTrue(jogador2.desfazerJogada());
		assertTrue(jogoDaVelha.isPosicaoLivre(Tabuleiro.CINCO));
		assertEquals(2,jogador2.getProximoValorASerJogado());
		
		jogador1.jogaNaPosicao(Tabuleiro.ZERO);
	}
	
	
	@Test
	public void joga() {

		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);


		List<JogoDaVelha> jogos =  new ArrayList<>();
		
		analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(Tabuleiro.UM).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();
		
		analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(Tabuleiro.OITO).doJogo(jogoDaVelha).recalcularEspaco();

		jogoDaVelha.semMascara().descreve();

		double maiorProbabilidade = 0.0;
		int melhorPosicao = 0;

		for (int i = 0; i < jogador1.getJogoDaVelha().getBaseCorrente().size(); i++) {

			
			if (jogador1.podeJogarNessaPosicao(i)) {// posicao livre
				//analisa probabilidade de gan

				double proba = analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(i).doJogo(jogoDaVelha).getProbabilidadeDeVencer();
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  " + melhorPosicao);
		System.out.println("\tMAIOR PROBA " + maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");

		analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();

		maiorProbabilidade = 0.0;
		melhorPosicao = 0;
		for (int i = 0; i < jogador2.getJogoDaVelha().getBaseCorrente().size(); i++) {

			if (jogador2.podeJogarNessaPosicao(i)) {// posicao livre
																// no tabuleiro
				double proba = analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(i).doJogo(jogoDaVelha).getProbabilidadeDeVencer();
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  " + melhorPosicao);
		System.out.println("\tMAIOR PROBA " + maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");

		analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();

		maiorProbabilidade = 0.0;
		melhorPosicao = 0;
		for (int i = 0; i < jogador1.getJogoDaVelha().getBaseCorrente().size(); i++) {

			if (jogador1.podeJogarNessaPosicao(i)) {// posicao livre
																// no tabuleiro
				double proba = analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(i).doJogo(jogoDaVelha).getProbabilidadeDeVencer();
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  " + melhorPosicao);
		System.out.println("\tMAIOR PROBA " + maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");

		

		analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();

		maiorProbabilidade = 0.0;
		melhorPosicao = 0;
		for (int i = 0; i < jogador2.getJogoDaVelha().getBaseCorrente().size(); i++) {

			if (jogador2.podeJogarNessaPosicao(i)) {// posicao livre
																// no tabuleiro

				double proba = analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(i).doJogo(jogoDaVelha).getProbabilidadeDeVencer();
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  " + melhorPosicao);
		System.out.println("\tMAIOR PROBA " + maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");
		
		analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();

		maiorProbabilidade = 0.0;
		melhorPosicao = 0;
		for (int i = 0; i < jogador1.getJogoDaVelha().getBaseCorrente().size(); i++) {

			if (jogador1.podeJogarNessaPosicao(i)) {// posicao livre
																// no tabuleiro
				double proba = analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(i).doJogo(jogoDaVelha).getProbabilidadeDeVencer();
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  "+ 	melhorPosicao);
		System.out.println("\tMAIOR PROBA "+ 	maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");


		analisador.noEspaco(jogos).depoisQueJogador(jogador1).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		
		jogoDaVelha.semMascara().descreve();

		maiorProbabilidade = 0.0;
		melhorPosicao = 0;
		for (int i = 0; i < jogador2.getJogoDaVelha().getBaseCorrente().size(); i++) {

			if (jogador2.podeJogarNessaPosicao(i)) {// posicao livre
																// no tabuleiro

				double proba = analisador.getProbabilidadeDeVencer(jogoDaVelha, i, 8, jogos);
				System.out.println("\tPROBABILIDADE  " + proba);

				if (proba >= maiorProbabilidade) {
					maiorProbabilidade = proba;
					melhorPosicao = i;
				}
			}
		}

		System.out.println("\n\n\tMELHOR POSICAO  "+ 	melhorPosicao);
		System.out.println("\tMAIOR PROBA "+ 	maiorProbabilidade);
		System.out.println("\n\n--------------------------------------------------------");
		if(!jogoDaVelha.alguemVenceu())
		analisador.noEspaco(jogos).depoisQueJogador(jogador2).jogarNaPosicao(melhorPosicao).doJogo(jogoDaVelha).recalcularEspaco();
		jogoDaVelha.semMascara().descreve();

		
	}

	@Test
	public void jogaNovo(){

		JogoDaVelha jogoDaVelha = new JogoDaVelha(new Tabuleiro());

		Jogador jogador1 = new Jogador(jogoDaVelha, JogadorComecaOJogo.SIM);
		Jogador jogador2 = new Jogador(jogoDaVelha, JogadorComecaOJogo.NAO);
		
		jogador1.setOponente(jogador2);
		jogador2.setOponente(jogador1);
		
		List<Integer> posicoesLivres1 = new ArrayList<>();
		List<Integer> posicoesLivres2 = new ArrayList<>();
		
		
		
	}
	
}
