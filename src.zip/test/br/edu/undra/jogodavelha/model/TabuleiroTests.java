package br.edu.undra.jogodavelha.model;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TabuleiroTests {

	@Test(expected = RuntimeException.class)
	public void construtorComBaseNula_RunTimeException() {

		List<Integer> base = null;
		Tabuleiro tabuleiro = new Tabuleiro(base);

	}

	@Test(expected = RuntimeException.class)
	public void baseComAlgumElementoNegativo() {
		{
			List<Integer> base = new ArrayList<>(Arrays.asList(-1, 0, 0, 2, 3, 4, 5, 6));
			Tabuleiro tabuleiro = new Tabuleiro(base);
		}
	}
	
	@Test(expected = RuntimeException.class)
	public void baseComMaisde9Elementos() {
		{
			List<Integer> base = new ArrayList<>(Arrays.asList(0,1, 0, 0, 2, 3, 4, 5, 6,7));
			Tabuleiro tabuleiro = new Tabuleiro(base);
		}
	}
	
	@Test
	public void segundoJogadorFezAlgumaTrica_baseIndicandoSegundoJogadorVencedor_Verdadeiro() {
		{
			//012 126
			//345 38*
			//678 457
			List<Integer> base = new ArrayList<>(Arrays.asList(1,2, 6, 3, 8, 0, 4, 5, 7));
			Tabuleiro tabuleiro = new Tabuleiro(base);
			
			assertTrue(tabuleiro.segundoJogadorFezAlgumaTrinca());
			assertEquals(0, tabuleiro.getBase().get(5).intValue());
			assertEquals(0, tabuleiro.getBaseCorrente().get(5).intValue());
			assertFalse(tabuleiro.primeiroJogadorFezAlgumaTrinca());
		
		}
		
	}
	
	@Test
	public void primeiroJogadorFezAlgumaTrica_baseIndicandoSegundoJogadorVencedor_Verdadeiro() {
		{
			//012 125
			//345 398
			//678 467
			List<Integer> base = new ArrayList<>(Arrays.asList(1,2, 5, 3, 9, 8, 4,6, 7));
			Tabuleiro tabuleiro = new Tabuleiro(base);
			
			assertTrue(tabuleiro.primeiroJogadorFezAlgumaTrinca());
			
			for(Integer i : tabuleiro.getBase()){
				assertNotEquals(0, tabuleiro.getBase().get(tabuleiro.getBase().indexOf(i)).intValue());
				assertNotEquals(0, tabuleiro.getBaseCorrente().get(tabuleiro.getBaseCorrente().indexOf(i)).intValue());
			}
			
			assertFalse(tabuleiro.segundoJogadorFezAlgumaTrinca());
		
		}
		
	}
	
}
